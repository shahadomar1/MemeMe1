//
//  Meme.swift
//  MemeMe1.0-App
//
//  Created by Yazeedo on 26/04/1440 AH.
//  Copyright © 1440 Yazeed ALZahrani. All rights reserved.
//

import UIKit

struct Meme {
    var topText: String = "TOP"
    var bottomText: String = "BOTTOM"
    var originalImage: UIImage?
    var memedImage: UIImage?

}
